(() => {
  'use strict';

  const { cleanText, normalizeCompanyUrl, companyId, randomDelay } = globalThis.LCC;
  const FOLLOWING_RE = /^(following|following\s+.+)$/i;
  const FOLLOW_RE = /^(follow|follow\s+.+)$/i;
  const UNFOLLOW_RE = /^(unfollow|unfollow\s+.+)$/i;

  const state = {
    running: false,
    stopRequested: false,
    discovered: [],
    completed: 0,
    failed: 0,
    skipped: 0,
    current: '',
    message: 'Ready'
  };

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function labelOf(element) {
    return cleanText(element?.getAttribute?.('aria-label') || element?.innerText || element?.textContent);
  }

  function isVisible(element) {
    if (!element || !element.isConnected) return false;
    const style = getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function findFollowingButton(container) {
    if (!container) return null;
    return [...container.querySelectorAll('button,[role="button"]')]
      .find((button) => isVisible(button) && FOLLOWING_RE.test(labelOf(button))) || null;
  }

  function findCard(anchor) {
    let node = anchor;
    for (let depth = 0; node && depth < 10; depth += 1, node = node.parentElement) {
      if (findFollowingButton(node)) return node;
    }
    return null;
  }

  function companyName(anchor, url) {
    const direct = cleanText(anchor.getAttribute('aria-label') || anchor.textContent);
    if (direct && direct.length < 120 && !/^(logo|view)/i.test(direct)) return direct;
    const slug = url.split('/company/')[1].replace(/\/$/, '');
    return slug.split('-').map((part) => part ? part[0].toUpperCase() + part.slice(1) : '').join(' ');
  }

  function scanCompanies() {
    const companies = new Map();
    for (const anchor of document.querySelectorAll('a[href*="/company/"]')) {
      const url = normalizeCompanyUrl(anchor.href);
      if (!url || companies.has(url)) continue;
      const card = findCard(anchor);
      if (!card) continue;
      const button = findFollowingButton(card);
      if (!button) continue;
      companies.set(url, {
        id: companyId(url),
        name: companyName(anchor, url),
        url
      });
    }
    state.discovered = [...companies.values()].sort((a, b) => a.name.localeCompare(b.name));
    return state.discovered;
  }

  function findCompanyElements(url) {
    for (const anchor of document.querySelectorAll('a[href*="/company/"]')) {
      if (normalizeCompanyUrl(anchor.href) !== url) continue;
      const card = findCard(anchor);
      const button = findFollowingButton(card);
      if (card && button) return { anchor, card, button };
    }
    return null;
  }

  function visibleAction(regex, exclude) {
    const dialogCandidates = [...document.querySelectorAll('[role="dialog"] button,[role="dialog"] [role="button"]')];
    const globalCandidates = [...document.querySelectorAll('button,[role="button"],[role="menuitem"]')];
    return [...dialogCandidates, ...globalCandidates].find((element) =>
      element !== exclude && isVisible(element) && regex.test(labelOf(element))
    ) || null;
  }

  async function waitFor(predicate, timeoutMs = 4500, intervalMs = 120) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const result = predicate();
      if (result) return result;
      await sleep(intervalMs);
    }
    return null;
  }

  function hasChangedToFollow(url) {
    for (const anchor of document.querySelectorAll('a[href*="/company/"]')) {
      if (normalizeCompanyUrl(anchor.href) !== url) continue;
      let node = anchor;
      for (let depth = 0; node && depth < 10; depth += 1, node = node.parentElement) {
        const candidate = [...node.querySelectorAll('button,[role="button"]')]
          .find((button) => isVisible(button) && FOLLOW_RE.test(labelOf(button)));
        if (candidate) return true;
      }
    }
    return false;
  }

  async function unfollowCompany(company) {
    const elements = findCompanyElements(company.url);
    if (!elements) return { ok: false, reason: 'Company card is no longer visible' };

    elements.button.scrollIntoView({ block: 'center', behavior: 'smooth' });
    await sleep(350);
    elements.button.click();

    for (let clickCount = 0; clickCount < 3; clickCount += 1) {
      if (await waitFor(() => hasChangedToFollow(company.url), 850, 100)) return { ok: true };
      const action = await waitFor(() => visibleAction(UNFOLLOW_RE, elements.button), 2500, 100);
      if (!action) break;
      action.click();
      await sleep(450);
    }

    if (await waitFor(() => hasChangedToFollow(company.url), 2800, 120)) return { ok: true };
    return { ok: false, reason: 'LinkedIn did not expose a usable Unfollow action' };
  }

  function ensureOverlay() {
    let overlay = document.getElementById('lcc-run-overlay');
    if (overlay) return overlay;
    overlay = document.createElement('aside');
    overlay.id = 'lcc-run-overlay';
    overlay.innerHTML = `
      <div class="lcc-overlay-brand">Clintware</div>
      <strong>Company Cleaner</strong>
      <div id="lcc-overlay-current">Preparing…</div>
      <div id="lcc-overlay-count">0 completed</div>
      <button id="lcc-overlay-stop" type="button">Stop run</button>`;
    document.body.appendChild(overlay);
    overlay.querySelector('#lcc-overlay-stop').addEventListener('click', () => {
      state.stopRequested = true;
      state.message = 'Stopping after the current company';
      updateOverlay();
    });
    return overlay;
  }

  function updateOverlay() {
    const overlay = document.getElementById('lcc-run-overlay');
    if (!overlay) return;
    overlay.querySelector('#lcc-overlay-current').textContent = state.current || state.message;
    overlay.querySelector('#lcc-overlay-count').textContent =
      `${state.completed} completed · ${state.failed} failed · ${state.skipped} skipped`;
  }

  function removeOverlay() {
    document.getElementById('lcc-run-overlay')?.remove();
  }

  async function loadMoreCompanies(previousCount) {
    window.scrollBy({ top: Math.max(window.innerHeight * 0.8, 600), behavior: 'smooth' });
    await sleep(1200);
    return scanCompanies().length > previousCount;
  }

  async function runCleanup(options) {
    if (state.running) return;
    state.running = true;
    state.stopRequested = false;
    state.completed = 0;
    state.failed = 0;
    state.skipped = 0;
    state.current = '';
    state.message = 'Scanning company Pages';
    ensureOverlay();
    updateOverlay();

    const max = Math.max(1, Math.min(250, Number(options.max) || 25));
    const selectedIds = new Set(options.selectedIds || []);
    const allMode = options.mode === 'all';
    const attempted = new Set();
    let idleScrolls = 0;

    while (!state.stopRequested && attempted.size < max) {
      const companies = scanCompanies();
      const next = companies.find((company) =>
        !attempted.has(company.id) && (allMode || selectedIds.has(company.id))
      );

      if (!next) {
        if (!allMode || !options.autoScroll || idleScrolls >= 3) break;
        const before = companies.length;
        const grew = await loadMoreCompanies(before);
        idleScrolls = grew ? 0 : idleScrolls + 1;
        continue;
      }

      idleScrolls = 0;
      attempted.add(next.id);
      state.current = `Unfollowing ${next.name}`;
      state.message = state.current;
      updateOverlay();

      try {
        const result = await unfollowCompany(next);
        if (result.ok) state.completed += 1;
        else {
          state.failed += 1;
          console.warn('[LinkedIn Company Cleaner]', next.name, result.reason);
        }
      } catch (error) {
        state.failed += 1;
        console.error('[LinkedIn Company Cleaner]', next.name, error);
      }

      updateOverlay();
      if (!state.stopRequested && attempted.size < max) {
        await sleep(randomDelay(options.minDelay, options.maxDelay));
      }
    }

    state.running = false;
    state.current = '';
    state.message = state.stopRequested ? 'Stopped' : 'Run complete';
    updateOverlay();
    await sleep(1800);
    removeOverlay();
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || typeof message.type !== 'string') return false;

    if (message.type === 'LCC_SCAN') {
      sendResponse({ ok: true, companies: scanCompanies(), state: { ...state } });
      return false;
    }

    if (message.type === 'LCC_STATE') {
      sendResponse({ ok: true, companies: scanCompanies(), state: { ...state } });
      return false;
    }

    if (message.type === 'LCC_START') {
      if (state.running) {
        sendResponse({ ok: false, error: 'A cleanup run is already active.' });
        return false;
      }
      sendResponse({ ok: true });
      runCleanup(message.options || {});
      return false;
    }

    if (message.type === 'LCC_STOP') {
      state.stopRequested = true;
      state.message = 'Stopping after the current company';
      updateOverlay();
      sendResponse({ ok: true });
      return false;
    }

    return false;
  });
})();
