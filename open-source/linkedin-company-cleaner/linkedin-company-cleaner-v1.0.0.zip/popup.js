(() => {
  'use strict';

  const $ = (selector) => document.querySelector(selector);
  const elements = {
    status: $('#status'), count: $('#count'), companies: $('#companies'), openPage: $('#openPage'),
    scan: $('#scan'), toggleAll: $('#toggleAll'), startSelected: $('#startSelected'),
    startAll: $('#startAll'), stop: $('#stop'), max: $('#max'), minDelay: $('#minDelay'),
    maxDelay: $('#maxDelay'), autoScroll: $('#autoScroll')
  };
  let activeTabId = null;
  let companies = [];

  function setStatus(text, isError = false) {
    elements.status.textContent = text;
    elements.status.classList.toggle('error', isError);
  }

  async function getActiveTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    activeTabId = tab?.id ?? null;
    return tab;
  }

  async function send(message) {
    if (!activeTabId) throw new Error('No active tab');
    return chrome.tabs.sendMessage(activeTabId, message);
  }

  function selectedIds() {
    return [...document.querySelectorAll('.company input:checked')].map((input) => input.value);
  }

  function updateButtons(running = false) {
    const selected = selectedIds().length;
    elements.startSelected.disabled = running || selected === 0;
    elements.startAll.disabled = running || companies.length === 0;
    elements.stop.disabled = !running;
    elements.scan.disabled = running;
  }

  function render(items, running = false) {
    companies = items || [];
    elements.count.textContent = `${companies.length} compan${companies.length === 1 ? 'y' : 'ies'} found`;
    if (!companies.length) {
      elements.companies.innerHTML = '<div class="empty">No company cards with a Following button were found on this page.</div>';
      updateButtons(running);
      return;
    }
    elements.companies.innerHTML = companies.map((company) => `
      <label class="company">
        <input type="checkbox" value="${company.id}">
        <span><span class="company-name"></span><span class="company-url"></span></span>
      </label>`).join('');
    [...elements.companies.querySelectorAll('.company')].forEach((row, index) => {
      row.querySelector('.company-name').textContent = companies[index].name;
      row.querySelector('.company-url').textContent = companies[index].url;
      row.querySelector('input').addEventListener('change', () => updateButtons(running));
    });
    updateButtons(running);
  }

  async function refresh(type = 'LCC_STATE') {
    const tab = await getActiveTab();
    if (!tab?.url?.startsWith('https://www.linkedin.com/')) {
      setStatus('Open LinkedIn, then use the company-following shortcut.', true);
      render([]);
      return;
    }
    try {
      const response = await send({ type });
      if (!response?.ok) throw new Error(response?.error || 'No response');
      const running = Boolean(response.state?.running);
      setStatus(running ? response.state.message || 'Cleanup running' : `${response.companies.length} company Pages ready`);
      render(response.companies, running);
    } catch {
      setStatus('Reload this LinkedIn tab once so the extension can connect.', true);
      render([]);
    }
  }

  async function start(mode) {
    const minSeconds = Math.max(1, Number(elements.minDelay.value) || 2.5);
    const maxSeconds = Math.max(minSeconds, Number(elements.maxDelay.value) || 5.5);
    const options = {
      mode,
      selectedIds: selectedIds(),
      max: Number(elements.max.value) || 25,
      minDelay: minSeconds * 1000,
      maxDelay: maxSeconds * 1000,
      autoScroll: elements.autoScroll.checked
    };
    const count = mode === 'all' ? Math.min(options.max, companies.length || options.max) : options.selectedIds.length;
    if (!confirm(`Unfollow up to ${count} LinkedIn company Page${count === 1 ? '' : 's'}? This is the only confirmation for this run.`)) return;
    const response = await send({ type: 'LCC_START', options });
    if (!response?.ok) {
      setStatus(response?.error || 'Could not start cleanup.', true);
      return;
    }
    setStatus('Cleanup started. Progress remains visible on LinkedIn.');
    updateButtons(true);
  }

  elements.openPage.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://www.linkedin.com/in/me/detail/interests/companies/' });
  });
  elements.scan.addEventListener('click', () => refresh('LCC_SCAN'));
  elements.toggleAll.addEventListener('click', () => {
    const boxes = [...document.querySelectorAll('.company input')];
    const shouldSelect = boxes.some((box) => !box.checked);
    boxes.forEach((box) => { box.checked = shouldSelect; });
    elements.toggleAll.textContent = shouldSelect ? 'Clear all' : 'Select all';
    updateButtons(false);
  });
  elements.startSelected.addEventListener('click', () => start('selected'));
  elements.startAll.addEventListener('click', () => start('all'));
  elements.stop.addEventListener('click', async () => {
    await send({ type: 'LCC_STOP' });
    setStatus('Stopping after the current company.');
  });

  refresh();
})();
