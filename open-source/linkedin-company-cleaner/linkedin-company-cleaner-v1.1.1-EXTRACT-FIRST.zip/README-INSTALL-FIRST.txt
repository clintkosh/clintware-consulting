LINKEDIN COMPANY CLEANER v1.1.1

IMPORTANT: You must EXTRACT the ZIP before using Load unpacked.
Do not select the ZIP file or the Downloads folder.

Correct folder:
The folder you select in Edge or Chrome must visibly contain:
  manifest.json
  popup.html
  popup.js
  content.js
  icons\

INSTALL
1. Right-click the downloaded ZIP.
2. Choose Extract All.
3. Open the extracted folder.
4. Confirm manifest.json is visible in that folder.
5. Open edge://extensions or chrome://extensions.
6. Enable Developer mode.
7. Choose Load unpacked.
8. Select the exact folder containing manifest.json.

You may double-click VERIFY-AND-OPEN-EXTENSIONS.cmd after extraction.
