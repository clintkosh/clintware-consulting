@echo off
setlocal
cd /d "%~dp0"
echo.
echo LinkedIn Company Cleaner v1.1.1 installation check
echo ---------------------------------------------------
if not exist "manifest.json" (
  echo ERROR: manifest.json is not in this folder.
  echo Extract the ZIP first, then run this file from the extracted folder.
  echo.
  pause
  exit /b 1
)
for %%F in (popup.html popup.js content.js lib.js background.js) do (
  if not exist "%%F" (
    echo ERROR: Required file %%F is missing.
    pause
    exit /b 1
  )
)
if not exist "icons\icon16.png" (
  echo ERROR: The icons folder is incomplete.
  pause
  exit /b 1
)
echo PASS: manifest.json and required extension files are present.
echo Select this exact folder when Edge or Chrome asks for Load unpacked:
echo %CD%
echo.
start "" explorer.exe "%CD%"
start "" msedge.exe "edge://extensions/" 2>nul
if errorlevel 1 start "" chrome.exe "chrome://extensions/" 2>nul
pause
endlocal
