LinkedIn Company Cleaner by Clintware v1.1.2

1. EXTRACT this ZIP first.
2. Open the extracted folder named linkedin-company-cleaner-v1.1.2.
3. You must see manifest.json directly in that folder.
4. In Edge, open edge://extensions and enable Developer mode.
5. Choose Load unpacked and select the exact folder that contains manifest.json.

v1.1.2 intentionally has NO icon declarations in manifest.json. This removes the icon-loading dependency that blocked v1.1.1 on Edge.
