@echo off
setlocal
cd /d "%~dp0"
echo Checking LinkedIn Company Cleaner v1.1.2...
if not exist manifest.json goto fail
if not exist background.js goto fail
if not exist popup.html goto fail
if not exist popup.js goto fail
if not exist popup.css goto fail
if not exist lib.js goto fail
if not exist content.js goto fail
if not exist content.css goto fail
powershell -NoProfile -Command "try { $m=Get-Content -Raw 'manifest.json' | ConvertFrom-Json; if($m.manifest_version -ne 3){exit 2}; if($m.icons -or $m.action.default_icon){exit 3}; exit 0 } catch { exit 4 }"
if errorlevel 1 goto fail
powershell -NoProfile -Command "Start-Process 'msedge.exe' 'edge://extensions/'" >nul 2>&1
if errorlevel 1 start "" "edge://extensions/"
echo.
echo PASS: This is the folder to select with Load unpacked:
echo %CD%
echo.
pause
exit /b 0
:fail
echo.
echo FAIL: This is not a valid extracted v1.1.2 extension folder.
echo Select the folder containing manifest.json directly.
echo.
pause
exit /b 1
