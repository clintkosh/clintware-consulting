'use strict';

// A minimal service worker keeps the Manifest V3 extension lifecycle explicit.
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ installedVersion: chrome.runtime.getManifest().version });
});
