(() => {
  'use strict';

  if (globalThis.__LCC_CONTENT_V110__) return;
  globalThis.__LCC_CONTENT_V110__ = true;

  const { cleanText, normalizeCompanyUrl, companyId, randomDelay } = globalThis.LCC;
  const FOLLOWING_CONTROL_RE = /^(following(?:\s+.+)?|unfollow(?:\s+.+)?|stop\s+following(?:\s+.+)?)$/i;
  const FOLLOW_STATE_RE = /^follow(?:\s+.+)?$/i;
  const CONFIRM_UNFOLLOW_RE = /^(unfollow(?:\s+.+)?|stop\s+following(?:\s+.+)?|yes,?\s*unfollow)$/i;
  const LOAD_MORE_RE = /^(show|load|see)\s+more(?:\s+results?)?$/i;

  const state = {
    running: false,
    stopRequested: false,
    discovered: [],
    completed: 0,
    failed: 0,
    skipped: 0,
    current: '',
    message: 'Ready',
    lastResult: null
  };

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function labelOf(element) {
    return cleanText(
      element?.getAttribute?.('aria-label') ||
      element?.getAttribute?.('title') ||
      element?.innerText ||
      element?.textContent
    );
  }

  function isVisible(element) {
    if (!element || !element.isConnected) return false;
    const style = getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isFollowingControl(element) {
    return Boolean(element && isVisible(element) && FOLLOWING_CONTROL_RE.test(labelOf(element)));
  }

  function findFollowingControl(container) {
    if (!container) return null;
    return [...container.querySelectorAll('button,[role="button"],[role="menuitem"]')]
      .find(isFollowingControl) || null;
  }

  function closestCardCandidate(anchor) {
    return anchor.closest?.('li, article, [data-view-name*="network-manager"], [data-view-name*="entity"], .artdeco-list__item, .mn-connection-card') || null;
  }

  function findCard(anchor) {
    const closest = closestCardCandidate(anchor);
    if (closest && findFollowingControl(closest)) return closest;

    let node = anchor;
    for (let depth = 0; node && depth < 12; depth += 1, node = node.parentElement) {
      if (findFollowingControl(node)) return node;
    }
    return null;
  }

  function usableName(value) {
    const name = cleanText(value)
      .replace(/^view\s+/i, '')
      .replace(/\s+(logo|page)$/i, '');
    if (!name || name.length > 120 || /^(logo|view|company)$/i.test(name)) return null;
    return name;
  }

  function companyName(anchor, url) {
    const aria = usableName(anchor.getAttribute('aria-label'));
    if (aria) return aria;
    const imageAlt = usableName(anchor.querySelector('img[alt]')?.getAttribute('alt'));
    if (imageAlt) return imageAlt;
    const direct = usableName(anchor.textContent);
    if (direct) return direct;
    const slug = url.split('/company/')[1].replace(/\/$/, '');
    return slug.split('-').map((part) => part ? part[0].toUpperCase() + part.slice(1) : '').join(' ');
  }

  function scanCompanies() {
    const companies = new Map();
    for (const anchor of document.querySelectorAll('a[href*="/company/"]')) {
      const url = normalizeCompanyUrl(anchor.href);
      if (!url || companies.has(url)) continue;
      const card = findCard(anchor);
      if (!card) continue;
      const control = findFollowingControl(card);
      if (!control) continue;
      companies.set(url, {
        id: companyId(url),
        name: companyName(anchor, url),
        url
      });
    }
    state.discovered = [...companies.values()].sort((a, b) => a.name.localeCompare(b.name));
    return state.discovered;
  }

  function findAnchor(url) {
    return [...document.querySelectorAll('a[href*="/company/"]')]
      .find((anchor) => normalizeCompanyUrl(anchor.href) === url) || null;
  }

  function findCompanyElements(url) {
    const anchor = findAnchor(url);
    if (!anchor) return null;
    const card = findCard(anchor);
    const control = findFollowingControl(card);
    return card && control ? { anchor, card, control } : null;
  }

  function isUnfollowed(url) {
    const anchor = findAnchor(url);
    if (!anchor) return true;
    const card = closestCardCandidate(anchor) || findCard(anchor) || anchor.parentElement;
    const controls = [...(card?.querySelectorAll?.('button,[role="button"]') || [])].filter(isVisible);
    return controls.some((control) => FOLLOW_STATE_RE.test(labelOf(control)) && !/following/i.test(labelOf(control)));
  }

  function visibleConfirmation(exclude) {
    const roots = [
      ...document.querySelectorAll('[role="dialog"], [role="menu"], .artdeco-modal, .artdeco-dropdown__content')
    ].filter(isVisible);

    for (const root of roots) {
      const action = [...root.querySelectorAll('button,[role="button"],[role="menuitem"]')]
        .find((element) => element !== exclude && isVisible(element) && CONFIRM_UNFOLLOW_RE.test(labelOf(element)));
      if (action) return action;
    }
    return null;
  }

  async function waitFor(predicate, timeoutMs = 4500, intervalMs = 100) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const result = predicate();
      if (result) return result;
      await sleep(intervalMs);
    }
    return null;
  }

  function activate(element) {
    element?.scrollIntoView?.({ block: 'center', behavior: 'auto' });
    element?.focus?.({ preventScroll: true });
    element?.click?.();
  }

  async function unfollowCompany(company) {
    const elements = findCompanyElements(company.url);
    if (!elements) return { ok: false, reason: 'Company row is no longer visible' };

    activate(elements.control);

    if (await waitFor(() => isUnfollowed(company.url), 1400, 90)) {
      return { ok: true, path: 'direct' };
    }

    const confirmation = await waitFor(() => visibleConfirmation(elements.control), 3000, 100);
    if (confirmation) {
      activate(confirmation);
      if (await waitFor(() => isUnfollowed(company.url), 3500, 100)) {
        return { ok: true, path: 'confirmed' };
      }
    }

    return { ok: false, reason: 'LinkedIn did not complete the Unfollow action' };
  }

  function ensureOverlay() {
    let overlay = document.getElementById('lcc-run-overlay');
    if (overlay) return overlay;
    overlay = document.createElement('aside');
    overlay.id = 'lcc-run-overlay';
    overlay.innerHTML = `
      <div class="lcc-overlay-head"><div><span>Clintware</span><strong>Company Cleaner</strong></div><button id="lcc-overlay-stop" type="button">Stop</button></div>
      <div id="lcc-overlay-current">Preparing…</div>
      <div id="lcc-overlay-count">0 completed</div>`;
    document.body.appendChild(overlay);
    overlay.querySelector('#lcc-overlay-stop').addEventListener('click', () => {
      state.stopRequested = true;
      state.message = 'Stopping after the current company';
      updateOverlay();
    });
    return overlay;
  }

  function updateOverlay() {
    const overlay = document.getElementById('lcc-run-overlay');
    if (!overlay) return;
    overlay.querySelector('#lcc-overlay-current').textContent = state.current || state.message;
    overlay.querySelector('#lcc-overlay-count').textContent =
      `${state.completed} completed · ${state.failed} failed · ${state.skipped} skipped`;
  }

  function removeOverlay() {
    document.getElementById('lcc-run-overlay')?.remove();
  }

  function findScrollContainer() {
    const firstCompany = document.querySelector('a[href*="/company/"]');
    let node = firstCompany?.parentElement;
    while (node && node !== document.body) {
      if (node.scrollHeight > node.clientHeight + 100) return node;
      node = node.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  async function loadMoreCompanies(previousCount) {
    const loadButton = [...document.querySelectorAll('button,[role="button"]')]
      .find((button) => isVisible(button) && LOAD_MORE_RE.test(labelOf(button)));
    if (loadButton) activate(loadButton);
    else {
      const scrollContainer = findScrollContainer();
      if (scrollContainer === document.scrollingElement || scrollContainer === document.documentElement) {
        window.scrollBy({ top: Math.max(window.innerHeight * 0.82, 650), behavior: 'auto' });
      } else {
        scrollContainer.scrollBy({ top: Math.max(scrollContainer.clientHeight * 0.82, 500), behavior: 'auto' });
      }
    }
    await sleep(1000);
    return scanCompanies().length > previousCount;
  }

  async function runCleanup(options) {
    if (state.running) return;
    state.running = true;
    state.stopRequested = false;
    state.completed = 0;
    state.failed = 0;
    state.skipped = 0;
    state.current = '';
    state.message = 'Scanning company Pages';
    state.lastResult = null;
    ensureOverlay();
    updateOverlay();

    const max = Math.max(1, Math.min(250, Number(options.max) || 25));
    const selectedIds = new Set(options.selectedIds || []);
    const allMode = options.mode === 'all';
    const attempted = new Set();
    let idleScrolls = 0;

    while (!state.stopRequested && attempted.size < max) {
      const companies = scanCompanies();
      const next = companies.find((company) =>
        !attempted.has(company.id) && (allMode || selectedIds.has(company.id))
      );

      if (!next) {
        if (!allMode || !options.autoScroll || idleScrolls >= 3) break;
        const before = companies.length;
        const grew = await loadMoreCompanies(before);
        idleScrolls = grew ? 0 : idleScrolls + 1;
        continue;
      }

      idleScrolls = 0;
      attempted.add(next.id);
      state.current = `Unfollowing ${next.name}`;
      state.message = state.current;
      updateOverlay();

      try {
        const result = await unfollowCompany(next);
        if (result.ok) state.completed += 1;
        else {
          state.failed += 1;
          console.warn('[LinkedIn Company Cleaner]', next.name, result.reason);
        }
      } catch (error) {
        state.failed += 1;
        console.error('[LinkedIn Company Cleaner]', next.name, error);
      }

      updateOverlay();
      if (!state.stopRequested && attempted.size < max) {
        await sleep(randomDelay(options.minDelay, options.maxDelay));
      }
    }

    state.running = false;
    state.current = '';
    state.message = state.stopRequested ? 'Stopped' : 'Run complete';
    state.lastResult = {
      completed: state.completed,
      failed: state.failed,
      skipped: state.skipped,
      stopped: state.stopRequested
    };
    updateOverlay();
    await sleep(900);
    removeOverlay();
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || typeof message.type !== 'string') return false;

    if (message.type === 'LCC_PING') {
      sendResponse({ ok: true, version: '1.1.2' });
      return false;
    }

    if (message.type === 'LCC_SCAN' || message.type === 'LCC_STATE') {
      sendResponse({ ok: true, companies: scanCompanies(), state: { ...state } });
      return false;
    }

    if (message.type === 'LCC_START') {
      if (state.running) {
        sendResponse({ ok: false, error: 'A cleanup run is already active.' });
        return false;
      }
      sendResponse({ ok: true });
      runCleanup(message.options || {});
      return false;
    }

    if (message.type === 'LCC_STOP') {
      state.stopRequested = true;
      state.message = 'Stopping after the current company';
      updateOverlay();
      sendResponse({ ok: true });
      return false;
    }

    return false;
  });
})();
