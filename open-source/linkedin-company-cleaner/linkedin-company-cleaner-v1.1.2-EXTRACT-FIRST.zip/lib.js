(() => {
  'use strict';

  function cleanText(value) {
    return String(value || '').replace(/\s+/g, ' ').trim();
  }

  function normalizeCompanyUrl(value) {
    try {
      const url = new URL(value, 'https://www.linkedin.com');
      if (url.hostname !== 'www.linkedin.com' && url.hostname !== 'linkedin.com') return null;
      const match = url.pathname.match(/^\/company\/([^/?#]+)/i);
      if (!match) return null;
      return `https://www.linkedin.com/company/${match[1].toLowerCase()}/`;
    } catch {
      return null;
    }
  }

  function companyId(url) {
    let hash = 2166136261;
    for (const char of String(url)) {
      hash ^= char.charCodeAt(0);
      hash = Math.imul(hash, 16777619);
    }
    return `company-${(hash >>> 0).toString(16)}`;
  }

  function randomDelay(minMs, maxMs, random = Math.random) {
    const min = Math.max(250, Number(minMs) || 2500);
    const max = Math.max(min, Number(maxMs) || 5500);
    return Math.round(min + random() * (max - min));
  }

  const api = { cleanText, normalizeCompanyUrl, companyId, randomDelay };
  globalThis.LCC = Object.assign(globalThis.LCC || {}, api);
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
