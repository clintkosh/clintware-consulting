(() => {
  'use strict';

  const FOLLOWED_COMPANIES_URL = 'https://www.linkedin.com/mynetwork/network-manager/company/?filterType=company';
  const $ = (selector) => document.querySelector(selector);
  const elements = {
    status: $('#status'), count: $('#count'), companies: $('#companies'), openPage: $('#openPage'),
    scan: $('#scan'), toggleAll: $('#toggleAll'), startSelected: $('#startSelected'),
    startAll: $('#startAll'), stop: $('#stop'), max: $('#max'), minDelay: $('#minDelay'),
    maxDelay: $('#maxDelay'), autoScroll: $('#autoScroll')
  };
  let activeTabId = null;
  let companies = [];
  let isRunning = false;

  function setStatus(text, mode = '') {
    elements.status.textContent = text;
    elements.status.classList.toggle('error', mode === 'error');
    elements.status.classList.toggle('success', mode === 'success');
  }

  async function getActiveTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    activeTabId = tab?.id ?? null;
    return tab;
  }

  async function injectContentScript() {
    if (!activeTabId) throw new Error('No active tab');
    await chrome.scripting.insertCSS({ target: { tabId: activeTabId }, files: ['content.css'] }).catch(() => {});
    await chrome.scripting.executeScript({ target: { tabId: activeTabId }, files: ['lib.js', 'content.js'] });
  }

  async function send(message) {
    if (!activeTabId) throw new Error('No active tab');
    try {
      return await chrome.tabs.sendMessage(activeTabId, message);
    } catch (firstError) {
      const tab = await chrome.tabs.get(activeTabId).catch(() => null);
      if (!tab?.url?.startsWith('https://www.linkedin.com/')) throw firstError;
      await injectContentScript();
      return chrome.tabs.sendMessage(activeTabId, message);
    }
  }

  function selectedIds() {
    return [...document.querySelectorAll('.company input:checked')].map((input) => input.value);
  }

  function updateButtons(running = isRunning) {
    isRunning = Boolean(running);
    const selected = selectedIds().length;
    elements.startSelected.disabled = isRunning || selected === 0;
    elements.startAll.disabled = isRunning || companies.length === 0;
    elements.stop.disabled = !isRunning;
    elements.scan.disabled = isRunning;
    elements.openPage.disabled = isRunning;
  }

  function render(items, running = false) {
    const previouslySelected = new Set(selectedIds());
    companies = Array.isArray(items) ? items : [];
    elements.count.textContent = `${companies.length} compan${companies.length === 1 ? 'y' : 'ies'}`;
    elements.toggleAll.textContent = 'Select all';
    if (!companies.length) {
      elements.companies.innerHTML = '<div class="empty">No followed company rows were found. Make sure the company manager has finished loading.</div>';
      updateButtons(running);
      return;
    }
    elements.companies.innerHTML = companies.map((company) => `
      <label class="company">
        <input type="checkbox" value="${company.id}">
        <span><span class="company-name"></span><span class="company-url"></span></span>
      </label>`).join('');
    [...elements.companies.querySelectorAll('.company')].forEach((row, index) => {
      const company = companies[index];
      row.querySelector('.company-name').textContent = company.name;
      row.querySelector('.company-url').textContent = company.url;
      const checkbox = row.querySelector('input');
      checkbox.checked = previouslySelected.has(company.id);
      checkbox.addEventListener('change', () => updateButtons(running));
    });
    updateButtons(running);
  }

  async function loadSettings() {
    const saved = await chrome.storage.local.get(['max', 'minDelay', 'maxDelay', 'autoScroll']);
    if (saved.max != null) elements.max.value = saved.max;
    if (saved.minDelay != null) elements.minDelay.value = saved.minDelay;
    if (saved.maxDelay != null) elements.maxDelay.value = saved.maxDelay;
    if (saved.autoScroll != null) elements.autoScroll.checked = saved.autoScroll;
  }

  function saveSettings() {
    chrome.storage.local.set({
      max: Number(elements.max.value) || 25,
      minDelay: Number(elements.minDelay.value) || 2.5,
      maxDelay: Number(elements.maxDelay.value) || 5.5,
      autoScroll: elements.autoScroll.checked
    });
  }

  async function refresh(type = 'LCC_STATE') {
    const tab = await getActiveTab();
    if (!tab?.url?.startsWith('https://www.linkedin.com/')) {
      setStatus('Open LinkedIn or use Find followed companies.', 'error');
      render([]);
      return;
    }
    try {
      setStatus(type === 'LCC_SCAN' ? 'Scanning visible company rows…' : 'Connecting…');
      const response = await send({ type });
      if (!response?.ok) throw new Error(response?.error || 'No response');
      const running = Boolean(response.state?.running);
      const count = response.companies?.length || 0;
      setStatus(running ? response.state.message || 'Cleanup running' : `${count} company Page${count === 1 ? '' : 's'} ready`, count ? 'success' : '');
      render(response.companies, running);
    } catch (error) {
      setStatus(`Could not connect: ${error?.message || 'unknown error'}`, 'error');
      render([]);
    }
  }

  async function start(mode) {
    try {
      const minSeconds = Math.max(0.5, Number(elements.minDelay.value) || 2.5);
      const maxSeconds = Math.max(minSeconds, Number(elements.maxDelay.value) || 5.5);
      const options = {
        mode,
        selectedIds: selectedIds(),
        max: Math.max(1, Math.min(250, Number(elements.max.value) || 25)),
        minDelay: minSeconds * 1000,
        maxDelay: maxSeconds * 1000,
        autoScroll: elements.autoScroll.checked
      };
      const count = mode === 'all' ? Math.min(options.max, companies.length) : options.selectedIds.length;
      if (!count) {
        setStatus('Select at least one company first.', 'error');
        return;
      }
      if (!confirm(`Unfollow up to ${count} company Page${count === 1 ? '' : 's'}?`)) return;
      const response = await send({ type: 'LCC_START', options });
      if (!response?.ok) throw new Error(response?.error || 'Could not start cleanup');
      setStatus('Cleanup started. Progress is visible on LinkedIn.', 'success');
      updateButtons(true);
    } catch (error) {
      setStatus(error?.message || 'Could not start cleanup.', 'error');
    }
  }

  async function openFollowedCompanies() {
    const tab = await getActiveTab();
    if (tab?.id != null) {
      await chrome.tabs.update(tab.id, { url: FOLLOWED_COMPANIES_URL });
    } else {
      await chrome.tabs.create({ url: FOLLOWED_COMPANIES_URL });
    }
    window.close();
  }

  [elements.max, elements.minDelay, elements.maxDelay, elements.autoScroll]
    .forEach((input) => input.addEventListener('change', saveSettings));

  elements.openPage.addEventListener('click', () => openFollowedCompanies().catch((error) => setStatus(error.message, 'error')));
  elements.scan.addEventListener('click', () => refresh('LCC_SCAN'));
  elements.toggleAll.addEventListener('click', () => {
    const boxes = [...document.querySelectorAll('.company input')];
    const shouldSelect = boxes.some((box) => !box.checked);
    boxes.forEach((box) => { box.checked = shouldSelect; });
    elements.toggleAll.textContent = shouldSelect ? 'Clear all' : 'Select all';
    updateButtons(false);
  });
  elements.startSelected.addEventListener('click', () => start('selected'));
  elements.startAll.addEventListener('click', () => start('all'));
  elements.stop.addEventListener('click', async () => {
    try {
      const response = await send({ type: 'LCC_STOP' });
      if (!response?.ok) throw new Error(response?.error || 'Could not stop cleanup');
      setStatus('Stopping after the current company.');
    } catch (error) {
      setStatus(error?.message || 'Could not stop cleanup.', 'error');
    }
  });

  globalThis.__LCC_POPUP_TEST__ = { FOLLOWED_COMPANIES_URL, refresh, start, openFollowedCompanies };
  loadSettings().finally(() => refresh());
})();
